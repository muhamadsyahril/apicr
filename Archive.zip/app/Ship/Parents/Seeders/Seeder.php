<?php

namespace App\Ship\Parents\Seeders;

use Apiato\Core\Abstracts\Seeders\Seeder as AbstractSeeder;

abstract class Seeder extends AbstractSeeder
{
}

<?php

namespace App\Ship\Parents\Notifications;

use Apiato\Core\Abstracts\Notifications\Notification as AbstractNotification;

class Notification extends AbstractNotification
{
}

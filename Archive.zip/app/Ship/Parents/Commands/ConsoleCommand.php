<?php

namespace App\Ship\Parents\Commands;

use Apiato\Core\Abstracts\Commands\ConsoleCommand as AbstractConsoleCommand;

abstract class ConsoleCommand extends AbstractConsoleCommand
{
}

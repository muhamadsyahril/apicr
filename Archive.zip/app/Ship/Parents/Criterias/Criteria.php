<?php

namespace App\Ship\Parents\Criterias;

use Apiato\Core\Abstracts\Criterias\Criteria as AbstractCriteria;

abstract class Criteria extends AbstractCriteria
{
}

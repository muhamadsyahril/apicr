<?php

namespace App\Ship\Parents\Events;

use Apiato\Core\Abstracts\Events\Event as AbstractEvent;

abstract class Event extends AbstractEvent
{
}

<?php

namespace App\Ship\Parents\Listeners;

use Apiato\Core\Abstracts\Listeners\Listener as AbstractListener;

abstract class Listener extends AbstractListener
{
}

<?php

namespace App\Ship\Parents\Actions;

use Apiato\Core\Abstracts\Actions\SubAction as AbstractSubAction;

abstract class SubAction extends AbstractSubAction
{
}

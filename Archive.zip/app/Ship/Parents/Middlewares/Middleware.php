<?php

namespace App\Ship\Parents\Middlewares;

use Apiato\Core\Abstracts\Middlewares\Middleware as AbstractMiddleware;

abstract class Middleware extends AbstractMiddleware
{
}

<?php

namespace App\Ship\Parents\Exceptions;

use Apiato\Core\Abstracts\Exceptions\Exception as AbstractException;

abstract class Exception extends AbstractException
{
}

<?php

namespace App\Ship\Parents\Mails;

use Apiato\Core\Abstracts\Mails\Mail as AbstractMail;

abstract class Mail extends AbstractMail
{
}

<?php

namespace App\Ship\Parents\Values;

use Apiato\Core\Abstracts\Values\Value as AbstractValue;

abstract class Value extends AbstractValue
{
}

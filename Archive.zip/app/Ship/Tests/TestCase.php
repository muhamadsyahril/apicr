<?php

namespace App\Ship\Tests;

use App\Ship\Parents\Tests\PhpUnit\TestCase as ShipTestCase;

class TestCase extends ShipTestCase
{
}

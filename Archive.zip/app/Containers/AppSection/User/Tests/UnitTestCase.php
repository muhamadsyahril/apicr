<?php

namespace App\Containers\AppSection\User\Tests;

use App\Ship\Parents\Tests\PhpUnit\TestCase as ParentTestCase;

/**
 * Class UnitTestCase.
 *
 * Use this class to add your container specific unit test helper functions.
 */
class UnitTestCase extends ParentTestCase
{
    // ..
}

<?php

namespace App\Containers\AppSection\Authorization\UI\API\Tests;

use App\Ship\Parents\Tests\PhpUnit\TestCase as ParentTestCase;

/**
 * Class ApiTestCase.
 *
 * Use this class to add your container specific API related test helper functions.
 */
class ApiTestCase extends ParentTestCase
{
    // ..
}
